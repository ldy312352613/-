//先获得页面中唯一的表单元素
var form=document.forms[0];
//Step1:为name为username和pwd的文本框绑定获得焦点事件
form.username.onfocus=
form.pwd.onfocus=function(){
  //this->当前文本框
  //当前文本框边框加粗
  this.className="txt_focus";
  //清除旁边div的class
  var div=this.parentNode
      .nextElementSibling
      .firstElementChild;
  div.className="";
}
form.username.onblur=function(){
  vali(this,/^\w{1,10}$/);
}
function vali(txt,reg){
  //清除当前文本框的class
  txt.className="";
  //获取旁边div
  var div=txt.parentNode
    .nextElementSibling
    .firstElementChild;
  //用reg测试当前文本框的内容
  //如果通过,就修改div的class为vali_success
  if(reg.test(txt.value))
    div.className="vali_success";
  //否则修改div的class为vali_fail
  else
    div.className="vali_fail";
}
form.pwd.onblur=function(){
  vali(this,/^\d{6}$/);
}