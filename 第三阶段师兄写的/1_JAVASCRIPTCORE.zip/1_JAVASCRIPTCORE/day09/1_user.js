//定义用户功能模块，包含三个功能
//先分别定义对象中的成员
var signin=function(){
  console.log("登录...");
}
var signup=function(){
  console.log("注册...");
}
var signout=function(){
  console.log("注销...");
}
//用一个对象结构，包裹所有成员
/*ES6中可简写: */
var user={
//属性名:属性值
  signin,//signin:signin,
  signup,//signup:signup,
  signout//signout:signout
}
//抛出整个对象模块
module.exports=user;