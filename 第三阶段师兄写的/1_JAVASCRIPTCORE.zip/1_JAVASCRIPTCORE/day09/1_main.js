//引入整个user模块对象
//const user=require("./1_user");
//调用user模块中提供的方法
//user.signin();
//user.signout();
//右键->在终端中打开
//或
//Ctrl+` 也可打开终端
//然后输入: node 主程序文件名
//比如: node 1_main.js
//执行过程: 执行require引入1_user.js中的模块，保存在变量user中
//调用user中的两个方法.

//将来开发中，都是先解构再单独使用
const {signin,signout}=require("./1_user");
signin();
signout();