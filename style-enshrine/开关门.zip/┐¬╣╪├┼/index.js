// 门，光线这类运动元素
var eleDoor = document.getElementById('door');
var eleLight = document.getElementById('light');
var eleDoorBox = document.getElementById('doorBox');
// 开门音效mp3
var eleAudioOpen = document.getElementById('audioOpen');
// 开门动画
var percentDoor = 0;
var fnOpenDoor = function () {
    percentDoor++;
    // 门完全打开后，进入下一个画面
    if (percentDoor == 100) {
        eleDoorBox.classList.add('active');
        return;
    }
    // 门打开
    eleDoor.style.transform = 'rotateY('+ (-90 * percentDoor / 100) +'deg)';
    eleLight.removeAttribute('hidden');
    // 光线变化
    eleLight.style.opacity = 0.8 - 0.9 * percentDoor / 100;

    setTimeout(fnOpenDoor, 16);
};
document.querySelector('#doorBtnIn').addEventListener('click', function () {
    eleAudioOpen.play();
    fnOpenDoor();
});